import Foundation

final class GoogleTranslateService: TranslationService {
    enum TranslationError: LocalizedError {
        case invalidURL
        case invalidResponse
        case invalidData

        var errorDescription: String? {
            switch self {
            case .invalidURL:
                return "Google Translate URL could not be created."
            case .invalidResponse:
                return "Google Translate returned an invalid response."
            case .invalidData:
                return "Google Translate response could not be parsed."
            }
        }
    }

    func translate(_ request: TranslationRequest) async throws -> TranslationResult {
        var components = URLComponents(
            string: "https://translate.googleapis.com/translate_a/single"
        )

        components?.queryItems = [
            URLQueryItem(name: "client", value: "gtx"),
            URLQueryItem(name: "sl", value: request.sourceLanguage ?? "auto"),
            URLQueryItem(name: "tl", value: request.targetLanguage),
            URLQueryItem(name: "dt", value: "t"),
            URLQueryItem(name: "q", value: request.text)
        ]

        guard let url = components?.url else {
            throw TranslationError.invalidURL
        }

        let session = NetworkSessionFactory.make(useSystemProxy: request.useSystemProxy)
        let (data, response) = try await session.data(from: url)

        guard let http = response as? HTTPURLResponse,
              http.statusCode == 200 else {
            throw TranslationError.invalidResponse
        }

        guard let json = try JSONSerialization.jsonObject(with: data) as? [Any],
              let rows = json.first as? [Any] else {
            throw TranslationError.invalidData
        }

        var translated = ""

        for row in rows {
            guard let part = row as? [Any],
                  let piece = part.first as? String else {
                continue
            }
            translated += piece
        }

        guard !translated.isEmpty else {
            throw TranslationError.invalidData
        }

        return TranslationResult(
            text: translated,
            detectedSourceLanguage: request.sourceLanguage
        )
    }
}
