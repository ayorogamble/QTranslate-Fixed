import Carbon
import Foundation

final class HotKeyManager {
    private var eventHandlerRef: EventHandlerRef?
    private var hotKeyRefs: [EventHotKeyRef] = []
    private var handlers: [UInt32: () -> Void] = [:]

    init() {
        installHandler()
    }

    deinit {
        unregisterAll()

        if let eventHandlerRef {
            RemoveEventHandler(eventHandlerRef)
        }
    }

    func unregisterAll() {
        for ref in hotKeyRefs {
            UnregisterEventHotKey(ref)
        }

        hotKeyRefs.removeAll()
        handlers.removeAll()
    }

    func register(
        id: UInt32,
        key: String,
        modifier: HotKeyModifier,
        handler: @escaping () -> Void
    ) {
        guard let keyCode = HotKeyKey.carbonKeyCode(for: key) else {
            return
        }

        let hotKeyID = EventHotKeyID(
            signature: 0x5154524E,
            id: id
        )

        var ref: EventHotKeyRef?

        let status = RegisterEventHotKey(
            keyCode,
            modifier.carbonFlags,
            hotKeyID,
            GetApplicationEventTarget(),
            0,
            &ref
        )

        guard status == noErr, let ref else {
            print("Failed to register hotkey \(id), status:", status)
            return
        }

        hotKeyRefs.append(ref)
        handlers[id] = handler
    }

    private func installHandler() {
        var eventType = EventTypeSpec(
            eventClass: OSType(kEventClassKeyboard),
            eventKind: UInt32(kEventHotKeyPressed)
        )

        InstallEventHandler(
            GetApplicationEventTarget(),
            { _, event, userData in
                guard let event, let userData else {
                    return OSStatus(eventNotHandledErr)
                }

                let manager = Unmanaged<HotKeyManager>
                    .fromOpaque(userData)
                    .takeUnretainedValue()

                var hotKeyID = EventHotKeyID()

                let status = GetEventParameter(
                    event,
                    EventParamName(kEventParamDirectObject),
                    EventParamType(typeEventHotKeyID),
                    nil,
                    MemoryLayout<EventHotKeyID>.size,
                    nil,
                    &hotKeyID
                )

                guard status == noErr else {
                    return status
                }

                manager.handlers[hotKeyID.id]?()
                return noErr
            },
            1,
            &eventType,
            Unmanaged.passUnretained(self).toOpaque(),
            &eventHandlerRef
        )
    }
}
