import Foundation

final class YandexTranslateService: TranslationService {
    enum YandexError: LocalizedError {
        case missingConfiguration
        case invalidResponse
        case invalidData

        var errorDescription: String? {
            switch self {
            case .missingConfiguration:
                return "Yandex API key or Folder ID is missing. Open Settings and configure Yandex Translate."
            case .invalidResponse:
                return "Yandex Translate returned an invalid response."
            case .invalidData:
                return "Yandex Translate response could not be parsed."
            }
        }
    }

    private struct Body: Encodable {
        let sourceLanguageCode: String?
        let targetLanguageCode: String
        let texts: [String]
        let folderId: String
    }

    private struct Response: Decodable {
        struct Item: Decodable {
            let text: String
            let detectedLanguageCode: String?
        }

        let translations: [Item]
    }

    func translate(_ request: TranslationRequest) async throws -> TranslationResult {
        let apiKey = AppSettings.yandexAPIKey.trimmingCharacters(in: .whitespacesAndNewlines)
        let folderID = AppSettings.yandexFolderID.trimmingCharacters(in: .whitespacesAndNewlines)

        guard !apiKey.isEmpty, !folderID.isEmpty else {
            throw YandexError.missingConfiguration
        }

        let url = URL(
            string: "https://translate.api.cloud.yandex.net/translate/v2/translate"
        )!

        var urlRequest = URLRequest(url: url)
        urlRequest.httpMethod = "POST"
        urlRequest.setValue("application/json", forHTTPHeaderField: "Content-Type")
        urlRequest.setValue("Api-Key \(apiKey)", forHTTPHeaderField: "Authorization")

        let body = Body(
            sourceLanguageCode: request.sourceLanguage,
            targetLanguageCode: request.targetLanguage,
            texts: [request.text],
            folderId: folderID
        )

        urlRequest.httpBody = try JSONEncoder().encode(body)

        let session = NetworkSessionFactory.make(useSystemProxy: request.useSystemProxy)
        let (data, response) = try await session.data(for: urlRequest)

        guard let http = response as? HTTPURLResponse,
              (200..<300).contains(http.statusCode) else {
            throw YandexError.invalidResponse
        }

        let decoded = try JSONDecoder().decode(Response.self, from: data)

        guard let first = decoded.translations.first else {
            throw YandexError.invalidData
        }

        return TranslationResult(
            text: first.text,
            detectedSourceLanguage: first.detectedLanguageCode
        )
    }
}
