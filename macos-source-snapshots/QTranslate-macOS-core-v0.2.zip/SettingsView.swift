import SwiftUI

struct SettingsView: View {
    @AppStorage("provider") private var provider = TranslationProvider.google.rawValue

    @AppStorage("sourceLanguage") private var sourceLanguage = "auto"
    @AppStorage("targetLanguage") private var targetLanguage = "ru"
    @AppStorage("reverseLanguage") private var reverseLanguage = "en"
    @AppStorage("smartBidirectional") private var smartBidirectional = true

    @AppStorage("useSystemProxy") private var useSystemProxy = true

    @AppStorage("deepLAPIKey") private var deepLAPIKey = ""
    @AppStorage("deepLFreeAPI") private var deepLFreeAPI = true

    @AppStorage("yandexAPIKey") private var yandexAPIKey = ""
    @AppStorage("yandexFolderID") private var yandexFolderID = ""

    @AppStorage("translateModifier") private var translateModifier = "Control"
    @AppStorage("translateKey") private var translateKey = "q"

    @AppStorage("replaceModifier") private var replaceModifier = "Control"
    @AppStorage("replaceKey") private var replaceKey = "w"

    @AppStorage("layoutModifier") private var layoutModifier = "Control"
    @AppStorage("layoutKey") private var layoutKey = "d"

    var body: some View {
        Form {
            Section("Translator") {
                Picker("Engine", selection: $provider) {
                    ForEach(TranslationProvider.allCases) { provider in
                        Text(provider.rawValue).tag(provider.rawValue)
                    }
                }

                Picker("Source language", selection: $sourceLanguage) {
                    ForEach(LanguageOption.popular) { language in
                        Text(language.name).tag(language.code)
                    }
                }

                Picker("Target language", selection: $targetLanguage) {
                    ForEach(LanguageOption.targets) { language in
                        Text(language.name).tag(language.code)
                    }
                }

                Toggle("Smart bidirectional mode", isOn: $smartBidirectional)

                if smartBidirectional {
                    Picker("Reverse target", selection: $reverseLanguage) {
                        ForEach(LanguageOption.targets) { language in
                            Text(language.name).tag(language.code)
                        }
                    }

                    Text("Example: target Russian + reverse English means English → Russian, but Russian → English.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }

            Section("Network") {
                Toggle("Use macOS system proxy", isOn: $useSystemProxy)

                Text("When enabled, translation requests follow the macOS system proxy settings.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            Section("DeepL") {
                SecureField("DeepL API key", text: $deepLAPIKey)
                Toggle("Use DeepL API Free endpoint", isOn: $deepLFreeAPI)
            }

            Section("Yandex Translate") {
                SecureField("Yandex API key", text: $yandexAPIKey)
                TextField("Yandex Folder ID", text: $yandexFolderID)
            }

            Section("Hotkeys") {
                HotKeyRow(
                    title: "Show translation",
                    modifier: $translateModifier,
                    key: $translateKey
                )

                HotKeyRow(
                    title: "Translate and replace",
                    modifier: $replaceModifier,
                    key: $replaceKey
                )

                HotKeyRow(
                    title: "Fix keyboard layout",
                    modifier: $layoutModifier,
                    key: $layoutKey
                )
            }

            HStack {
                Spacer()

                Button("Apply") {
                    NotificationCenter.default.post(
                        name: AppSettings.settingsChanged,
                        object: nil
                    )
                }
                .keyboardShortcut(.defaultAction)
            }
        }
        .formStyle(.grouped)
        .frame(width: 560, height: 720)
        .padding()
    }
}

private struct HotKeyRow: View {
    let title: String
    @Binding var modifier: String
    @Binding var key: String

    var body: some View {
        HStack {
            Text(title)
                .frame(width: 170, alignment: .leading)

            Picker("", selection: $modifier) {
                ForEach(HotKeyModifier.allCases) { item in
                    Text(item.rawValue).tag(item.rawValue)
                }
            }
            .labelsHidden()
            .frame(width: 170)

            Picker("", selection: $key) {
                ForEach(HotKeyKey.available, id: \.self) { key in
                    Text(key.uppercased()).tag(key)
                }
            }
            .labelsHidden()
            .frame(width: 80)
        }
    }
}
