import Foundation

enum AppSettings {
    static let settingsChanged = Notification.Name("QTranslateSettingsChanged")

    static var provider: TranslationProvider {
        get {
            let raw = UserDefaults.standard.string(forKey: "provider") ?? TranslationProvider.google.rawValue
            return TranslationProvider(rawValue: raw) ?? .google
        }
        set {
            UserDefaults.standard.set(newValue.rawValue, forKey: "provider")
        }
    }

    static var sourceLanguage: String {
        UserDefaults.standard.string(forKey: "sourceLanguage") ?? "auto"
    }

    static var targetLanguage: String {
        UserDefaults.standard.string(forKey: "targetLanguage") ?? "ru"
    }

    static var reverseLanguage: String {
        UserDefaults.standard.string(forKey: "reverseLanguage") ?? "en"
    }

    static var smartBidirectional: Bool {
        if UserDefaults.standard.object(forKey: "smartBidirectional") == nil {
            return true
        }
        return UserDefaults.standard.bool(forKey: "smartBidirectional")
    }

    static var useSystemProxy: Bool {
        if UserDefaults.standard.object(forKey: "useSystemProxy") == nil {
            return true
        }
        return UserDefaults.standard.bool(forKey: "useSystemProxy")
    }

    static var deepLAPIKey: String {
        UserDefaults.standard.string(forKey: "deepLAPIKey") ?? ""
    }

    static var deepLFreeAPI: Bool {
        if UserDefaults.standard.object(forKey: "deepLFreeAPI") == nil {
            return true
        }
        return UserDefaults.standard.bool(forKey: "deepLFreeAPI")
    }

    static var yandexAPIKey: String {
        UserDefaults.standard.string(forKey: "yandexAPIKey") ?? ""
    }

    static var yandexFolderID: String {
        UserDefaults.standard.string(forKey: "yandexFolderID") ?? ""
    }

    static var translateModifier: String {
        UserDefaults.standard.string(forKey: "translateModifier") ?? "control"
    }

    static var translateKey: String {
        UserDefaults.standard.string(forKey: "translateKey") ?? "q"
    }

    static var replaceModifier: String {
        UserDefaults.standard.string(forKey: "replaceModifier") ?? "control"
    }

    static var replaceKey: String {
        UserDefaults.standard.string(forKey: "replaceKey") ?? "w"
    }

    static var layoutModifier: String {
        UserDefaults.standard.string(forKey: "layoutModifier") ?? "control"
    }

    static var layoutKey: String {
        UserDefaults.standard.string(forKey: "layoutKey") ?? "d"
    }
}
