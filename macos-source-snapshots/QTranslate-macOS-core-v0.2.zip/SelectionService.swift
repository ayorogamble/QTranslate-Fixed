import AppKit
import ApplicationServices

final class SelectionService {
    func selectedText() -> String? {
        if let text = selectedTextViaAccessibility(),
           !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            return text
        }

        return selectedTextViaClipboard()
    }

    func replaceSelectedText(with text: String) -> Bool {
        if replaceViaAccessibility(text) {
            return true
        }

        return replaceViaClipboard(text)
    }

    private func focusedElement() -> AXUIElement? {
        let systemWide = AXUIElementCreateSystemWide()
        var focusedValue: CFTypeRef?

        guard AXUIElementCopyAttributeValue(
            systemWide,
            kAXFocusedUIElementAttribute as CFString,
            &focusedValue
        ) == .success,
        let focusedValue else {
            return nil
        }

        return (focusedValue as! AXUIElement)
    }

    private func selectedTextViaAccessibility() -> String? {
        guard let element = focusedElement() else {
            return nil
        }

        var selectedValue: CFTypeRef?

        guard AXUIElementCopyAttributeValue(
            element,
            kAXSelectedTextAttribute as CFString,
            &selectedValue
        ) == .success else {
            return nil
        }

        return selectedValue as? String
    }

    private func replaceViaAccessibility(_ text: String) -> Bool {
        guard let element = focusedElement() else {
            return false
        }

        return AXUIElementSetAttributeValue(
            element,
            kAXSelectedTextAttribute as CFString,
            text as CFString
        ) == .success
    }

    private func selectedTextViaClipboard() -> String? {
        let pasteboard = NSPasteboard.general
        let oldItems = pasteboard.pasteboardItems

        pasteboard.clearContents()
        postCommandKey(virtualKey: 8) // C

        Thread.sleep(forTimeInterval: 0.15)

        let selected = pasteboard.string(forType: .string)
        restorePasteboard(oldItems)

        return selected
    }

    private func replaceViaClipboard(_ text: String) -> Bool {
        let pasteboard = NSPasteboard.general
        let oldItems = pasteboard.pasteboardItems

        pasteboard.clearContents()

        guard pasteboard.setString(text, forType: .string) else {
            return false
        }

        postCommandKey(virtualKey: 9) // V
        Thread.sleep(forTimeInterval: 0.10)

        restorePasteboard(oldItems)
        return true
    }

    private func restorePasteboard(_ items: [NSPasteboardItem]?) {
        guard let items else {
            return
        }

        let copies: [NSPasteboardItem] = items.map { oldItem in
            let newItem = NSPasteboardItem()
            for type in oldItem.types {
                if let data = oldItem.data(forType: type) {
                    newItem.setData(data, forType: type)
                }
            }
            return newItem
        }

        NSPasteboard.general.clearContents()
        NSPasteboard.general.writeObjects(copies)
    }

    private func postCommandKey(virtualKey: CGKeyCode) {
        guard let source = CGEventSource(stateID: .hidSystemState) else {
            return
        }

        let down = CGEvent(
            keyboardEventSource: source,
            virtualKey: virtualKey,
            keyDown: true
        )

        let up = CGEvent(
            keyboardEventSource: source,
            virtualKey: virtualKey,
            keyDown: false
        )

        down?.flags = .maskCommand
        up?.flags = .maskCommand

        down?.post(tap: .cghidEventTap)
        up?.post(tap: .cghidEventTap)
    }
}
