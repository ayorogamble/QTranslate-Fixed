import Foundation

enum KeyboardLayoutFixer {
    private static let english = Array("qwertyuiop[]asdfghjkl;'zxcvbnm,./`")
    private static let russian = Array("йцукенгшщзхъфывапролджэячсмитьбю.ё")

    static func fix(_ text: String) -> String {
        let latinScore = text.reduce(0) { $0 + (isLatinKeyboardCharacter($1) ? 1 : 0) }
        let russianScore = text.reduce(0) { $0 + (isRussianKeyboardCharacter($1) ? 1 : 0) }

        if latinScore >= russianScore {
            return map(text, from: english, to: russian)
        } else {
            return map(text, from: russian, to: english)
        }
    }

    private static func map(_ text: String, from: [Character], to: [Character]) -> String {
        var lowerMap: [Character: Character] = [:]
        var upperMap: [Character: Character] = [:]

        for (source, target) in zip(from, to) {
            lowerMap[source] = target

            let sourceUpperString = String(source).uppercased()
            let targetUpperString = String(target).uppercased()

            if let sourceUpper = sourceUpperString.first,
               let targetUpper = targetUpperString.first {
                upperMap[sourceUpper] = targetUpper
            }
        }

        return String(text.map { char in
            if let mapped = lowerMap[char] {
                return mapped
            }
            if let mapped = upperMap[char] {
                return mapped
            }
            return char
        })
    }

    private static func isLatinKeyboardCharacter(_ char: Character) -> Bool {
        english.contains(Character(String(char).lowercased()))
    }

    private static func isRussianKeyboardCharacter(_ char: Character) -> Bool {
        russian.contains(Character(String(char).lowercased()))
    }
}
