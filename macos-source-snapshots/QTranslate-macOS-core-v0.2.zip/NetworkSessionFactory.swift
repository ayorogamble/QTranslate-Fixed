import Foundation

enum NetworkSessionFactory {
    static func make(useSystemProxy: Bool) -> URLSession {
        if useSystemProxy {
            return URLSession(configuration: .default)
        }

        let configuration = URLSessionConfiguration.ephemeral

        // An empty explicit proxy dictionary prevents inheriting configured
        // HTTP/HTTPS/SOCKS proxy entries in current Foundation implementations.
        configuration.connectionProxyDictionary = [:]

        return URLSession(configuration: configuration)
    }
}
