import Foundation

struct LanguageOption: Identifiable, Hashable {
    let code: String
    let name: String

    var id: String { code }

    static let auto = LanguageOption(code: "auto", name: "Auto Detect")

    static let popular: [LanguageOption] = [
        .auto,
        LanguageOption(code: "ru", name: "Russian"),
        LanguageOption(code: "en", name: "English"),
        LanguageOption(code: "de", name: "German"),
        LanguageOption(code: "fr", name: "French"),
        LanguageOption(code: "es", name: "Spanish"),
        LanguageOption(code: "it", name: "Italian"),
        LanguageOption(code: "pt", name: "Portuguese"),
        LanguageOption(code: "uk", name: "Ukrainian"),
        LanguageOption(code: "pl", name: "Polish"),
        LanguageOption(code: "tr", name: "Turkish"),
        LanguageOption(code: "nl", name: "Dutch"),
        LanguageOption(code: "cs", name: "Czech"),
        LanguageOption(code: "sv", name: "Swedish"),
        LanguageOption(code: "fi", name: "Finnish"),
        LanguageOption(code: "da", name: "Danish"),
        LanguageOption(code: "el", name: "Greek"),
        LanguageOption(code: "ro", name: "Romanian"),
        LanguageOption(code: "hu", name: "Hungarian"),
        LanguageOption(code: "bg", name: "Bulgarian"),
        LanguageOption(code: "ar", name: "Arabic"),
        LanguageOption(code: "zh", name: "Chinese"),
        LanguageOption(code: "ja", name: "Japanese"),
        LanguageOption(code: "ko", name: "Korean")
    ]

    static var targets: [LanguageOption] {
        popular.filter { $0.code != "auto" }
    }

    static func name(for code: String) -> String {
        popular.first(where: { $0.code == code })?.name ?? code.uppercased()
    }
}
