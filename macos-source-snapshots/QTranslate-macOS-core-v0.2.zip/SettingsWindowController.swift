import AppKit
import SwiftUI

final class SettingsWindowController {
    private var window: NSWindow?

    func show() {
        if let window {
            window.makeKeyAndOrderFront(nil)
            NSApp.activate(ignoringOtherApps: true)
            return
        }

        let hostingController = NSHostingController(
            rootView: SettingsView()
        )

        let window = NSWindow(
            contentViewController: hostingController
        )

        window.title = "QTranslate Settings"
        window.styleMask = [
            .titled,
            .closable,
            .miniaturizable
        ]
        window.setContentSize(NSSize(width: 600, height: 760))
        window.center()
        window.isReleasedWhenClosed = false

        self.window = window

        window.makeKeyAndOrderFront(nil)
        NSApp.activate(ignoringOtherApps: true)
    }
}
