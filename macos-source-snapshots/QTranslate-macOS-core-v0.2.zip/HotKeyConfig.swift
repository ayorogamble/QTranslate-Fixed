import Carbon
import Foundation

enum HotKeyModifier: String, CaseIterable, Identifiable {
    case control = "Control"
    case option = "Option"
    case command = "Command"
    case controlShift = "Control + Shift"
    case optionShift = "Option + Shift"
    case commandShift = "Command + Shift"
    case controlOption = "Control + Option"

    var id: String { rawValue }

    var carbonFlags: UInt32 {
        switch self {
        case .control:
            return UInt32(controlKey)
        case .option:
            return UInt32(optionKey)
        case .command:
            return UInt32(cmdKey)
        case .controlShift:
            return UInt32(controlKey | shiftKey)
        case .optionShift:
            return UInt32(optionKey | shiftKey)
        case .commandShift:
            return UInt32(cmdKey | shiftKey)
        case .controlOption:
            return UInt32(controlKey | optionKey)
        }
    }

    static func fromStored(_ value: String) -> HotKeyModifier {
        HotKeyModifier.allCases.first(where: {
            $0.rawValue.lowercased() == value.lowercased()
        }) ?? .control
    }
}

enum HotKeyKey {
    static let available = Array("abcdefghijklmnopqrstuvwxyz").map(String.init)

    static func carbonKeyCode(for key: String) -> UInt32? {
        let map: [String: Int] = [
            "a": kVK_ANSI_A, "b": kVK_ANSI_B, "c": kVK_ANSI_C,
            "d": kVK_ANSI_D, "e": kVK_ANSI_E, "f": kVK_ANSI_F,
            "g": kVK_ANSI_G, "h": kVK_ANSI_H, "i": kVK_ANSI_I,
            "j": kVK_ANSI_J, "k": kVK_ANSI_K, "l": kVK_ANSI_L,
            "m": kVK_ANSI_M, "n": kVK_ANSI_N, "o": kVK_ANSI_O,
            "p": kVK_ANSI_P, "q": kVK_ANSI_Q, "r": kVK_ANSI_R,
            "s": kVK_ANSI_S, "t": kVK_ANSI_T, "u": kVK_ANSI_U,
            "v": kVK_ANSI_V, "w": kVK_ANSI_W, "x": kVK_ANSI_X,
            "y": kVK_ANSI_Y, "z": kVK_ANSI_Z
        ]

        return map[key.lowercased()].map(UInt32.init)
    }
}
