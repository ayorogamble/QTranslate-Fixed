import Foundation

struct TranslationRequest {
    let text: String
    let sourceLanguage: String?
    let targetLanguage: String
    let useSystemProxy: Bool
}

struct TranslationResult {
    let text: String
    let detectedSourceLanguage: String?
}

protocol TranslationService {
    func translate(_ request: TranslationRequest) async throws -> TranslationResult
}
