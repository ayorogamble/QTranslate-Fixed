QTranslate macOS core v0.2

Replace your current project core files with the Swift files in this folder.

Required Xcode configuration:
1. macOS target
2. App Sandbox removed
3. Hardened Runtime can stay enabled
4. Every Swift file must have Target Membership enabled for your QTranslate target
5. Accessibility permission must be enabled in System Settings

Default hotkeys:
Control + Q = show translation
Control + W = translate and replace selected text
Control + D = fix EN/RU keyboard layout

Settings:
Click QT in the macOS menu bar, then Settings…

Translator engines:
Google works without an API key through the current unofficial web client endpoint.
DeepL uses the official API. Enter your own DeepL API key in Settings.
Yandex uses Yandex Cloud Translate API v2. Enter an API key and Folder ID in Settings.

Network:
Use macOS system proxy is ON by default.

Smart bidirectional:
Default target = Russian
Default reverse target = English
With Auto Detect enabled:
English text -> Russian
Russian text -> English
Other languages -> Russian

Before public release:
Move DeepL and Yandex API secrets from UserDefaults to macOS Keychain.
The current SettingsView stores them through AppStorage for development convenience.
