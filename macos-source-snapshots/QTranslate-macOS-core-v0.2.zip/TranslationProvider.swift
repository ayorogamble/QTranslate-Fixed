import Foundation

enum TranslationProvider: String, CaseIterable, Identifiable {
    case google = "Google Translate"
    case deepl = "DeepL"
    case yandex = "Yandex Translate"

    var id: String { rawValue }
}
