import AppKit
import ApplicationServices

final class AppDelegate: NSObject, NSApplicationDelegate {
    private var statusItem: NSStatusItem!

    private let selectionService = SelectionService()
    private let translationManager = TranslationManager()
    private let hotKeyManager = HotKeyManager()
    private let settingsWindowController = SettingsWindowController()

    func applicationDidFinishLaunching(_ notification: Notification) {
        NSApp.setActivationPolicy(.accessory)

        requestAccessibilityPermission()
        setupMenuBar()
        registerHotKeys()

        NotificationCenter.default.addObserver(
            self,
            selector: #selector(settingsChanged),
            name: AppSettings.settingsChanged,
            object: nil
        )
    }

    private func requestAccessibilityPermission() {
        let key = kAXTrustedCheckOptionPrompt.takeUnretainedValue() as String

        let options: CFDictionary = [
            key: true
        ] as CFDictionary

        AXIsProcessTrustedWithOptions(options)
    }

    private func setupMenuBar() {
        statusItem = NSStatusBar.system.statusItem(
            withLength: NSStatusItem.variableLength
        )

        statusItem.button?.title = "QT"

        rebuildMenu()
    }

    private func rebuildMenu() {
        let menu = NSMenu()

        let info = NSMenuItem(
            title: "\(AppSettings.provider.rawValue) • \(directionDescription())",
            action: nil,
            keyEquivalent: ""
        )
        menu.addItem(info)

        menu.addItem(.separator())

        let translate = NSMenuItem(
            title: "Translate selected text",
            action: #selector(translateSelectedText),
            keyEquivalent: ""
        )
        translate.target = self
        menu.addItem(translate)

        let replace = NSMenuItem(
            title: "Translate and replace",
            action: #selector(translateAndReplace),
            keyEquivalent: ""
        )
        replace.target = self
        menu.addItem(replace)

        let layout = NSMenuItem(
            title: "Fix keyboard layout",
            action: #selector(fixKeyboardLayout),
            keyEquivalent: ""
        )
        layout.target = self
        menu.addItem(layout)

        menu.addItem(.separator())

        let settings = NSMenuItem(
            title: "Settings…",
            action: #selector(showSettings),
            keyEquivalent: ","
        )
        settings.target = self
        menu.addItem(settings)

        menu.addItem(.separator())

        let quit = NSMenuItem(
            title: "Quit QTranslate",
            action: #selector(quitApp),
            keyEquivalent: "q"
        )
        quit.target = self
        menu.addItem(quit)

        statusItem.menu = menu
    }

    private func registerHotKeys() {
        hotKeyManager.unregisterAll()

        hotKeyManager.register(
            id: 1,
            key: AppSettings.translateKey,
            modifier: HotKeyModifier.fromStored(AppSettings.translateModifier)
        ) { [weak self] in
            DispatchQueue.main.async {
                self?.translateSelectedText()
            }
        }

        hotKeyManager.register(
            id: 2,
            key: AppSettings.replaceKey,
            modifier: HotKeyModifier.fromStored(AppSettings.replaceModifier)
        ) { [weak self] in
            DispatchQueue.main.async {
                self?.translateAndReplace()
            }
        }

        hotKeyManager.register(
            id: 3,
            key: AppSettings.layoutKey,
            modifier: HotKeyModifier.fromStored(AppSettings.layoutModifier)
        ) { [weak self] in
            DispatchQueue.main.async {
                self?.fixKeyboardLayout()
            }
        }
    }

    @objc
    private func settingsChanged() {
        registerHotKeys()
        rebuildMenu()
    }

    @objc
    private func translateSelectedText() {
        guard let text = selectedTextOrShowError() else {
            return
        }

        Task { [weak self] in
            guard let self else { return }

            do {
                let result = try await translationManager.translate(text: text)

                await MainActor.run {
                    let source = result.sourceLanguage.map(LanguageOption.name(for:)) ?? "Auto"
                    let target = LanguageOption.name(for: result.targetLanguage)

                    self.showMessage(
                        title: "\(result.provider.rawValue) • \(source) → \(target)",
                        text: result.text
                    )
                }
            } catch {
                await MainActor.run {
                    self.showMessage(
                        title: "Translation error",
                        text: error.localizedDescription
                    )
                }
            }
        }
    }

    @objc
    private func translateAndReplace() {
        guard let text = selectedTextOrShowError() else {
            return
        }

        Task { [weak self] in
            guard let self else { return }

            do {
                let result = try await translationManager.translate(text: text)

                await MainActor.run {
                    if !self.selectionService.replaceSelectedText(with: result.text) {
                        self.showMessage(
                            title: "QTranslate",
                            text: "Could not replace the selected text in this application."
                        )
                    }
                }
            } catch {
                await MainActor.run {
                    self.showMessage(
                        title: "Translation error",
                        text: error.localizedDescription
                    )
                }
            }
        }
    }

    @objc
    private func fixKeyboardLayout() {
        guard let text = selectedTextOrShowError() else {
            return
        }

        let fixed = KeyboardLayoutFixer.fix(text)

        if !selectionService.replaceSelectedText(with: fixed) {
            showMessage(
                title: "QTranslate",
                text: "Could not replace the selected text in this application."
            )
        }
    }

    private func selectedTextOrShowError() -> String? {
        guard AXIsProcessTrusted() else {
            showMessage(
                title: "Accessibility permission required",
                text: "Enable QTranslate in System Settings → Privacy & Security → Accessibility."
            )
            return nil
        }

        guard let text = selectionService.selectedText(),
              !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            showMessage(
                title: "QTranslate",
                text: "No selected text found."
            )
            return nil
        }

        return text
    }

    @objc
    private func showSettings() {
        settingsWindowController.show()
    }

    @objc
    private func quitApp() {
        NSApplication.shared.terminate(nil)
    }

    private func directionDescription() -> String {
        let source = AppSettings.sourceLanguage == "auto"
            ? "Auto"
            : LanguageOption.name(for: AppSettings.sourceLanguage)

        let target = LanguageOption.name(for: AppSettings.targetLanguage)

        if AppSettings.smartBidirectional {
            let reverse = LanguageOption.name(for: AppSettings.reverseLanguage)
            return "\(source) → \(target) / \(reverse)"
        }

        return "\(source) → \(target)"
    }

    private func showMessage(title: String, text: String) {
        let alert = NSAlert()
        alert.messageText = title
        alert.informativeText = text
        alert.addButton(withTitle: "OK")

        NSApp.activate(ignoringOtherApps: true)
        alert.runModal()
    }
}
