import Foundation

final class DeepLTranslateService: TranslationService {
    enum DeepLError: LocalizedError {
        case missingAPIKey
        case invalidResponse
        case invalidData

        var errorDescription: String? {
            switch self {
            case .missingAPIKey:
                return "DeepL API key is missing. Open Settings and add your DeepL API key."
            case .invalidResponse:
                return "DeepL returned an invalid response."
            case .invalidData:
                return "DeepL response could not be parsed."
            }
        }
    }

    private struct Body: Encodable {
        let text: [String]
        let target_lang: String
        let source_lang: String?
    }

    private struct Response: Decodable {
        struct Item: Decodable {
            let detected_source_language: String?
            let text: String
        }

        let translations: [Item]
    }

    func translate(_ request: TranslationRequest) async throws -> TranslationResult {
        let apiKey = AppSettings.deepLAPIKey.trimmingCharacters(in: .whitespacesAndNewlines)

        guard !apiKey.isEmpty else {
            throw DeepLError.missingAPIKey
        }

        let base = AppSettings.deepLFreeAPI
            ? "https://api-free.deepl.com"
            : "https://api.deepl.com"

        let url = URL(string: "\(base)/v2/translate")!

        var urlRequest = URLRequest(url: url)
        urlRequest.httpMethod = "POST"
        urlRequest.setValue("application/json", forHTTPHeaderField: "Content-Type")
        urlRequest.setValue("DeepL-Auth-Key \(apiKey)", forHTTPHeaderField: "Authorization")

        let body = Body(
            text: [request.text],
            target_lang: deepLTargetCode(request.targetLanguage),
            source_lang: request.sourceLanguage.map(deepLSourceCode)
        )

        urlRequest.httpBody = try JSONEncoder().encode(body)

        let session = NetworkSessionFactory.make(useSystemProxy: request.useSystemProxy)
        let (data, response) = try await session.data(for: urlRequest)

        guard let http = response as? HTTPURLResponse,
              (200..<300).contains(http.statusCode) else {
            throw DeepLError.invalidResponse
        }

        let decoded = try JSONDecoder().decode(Response.self, from: data)

        guard let first = decoded.translations.first else {
            throw DeepLError.invalidData
        }

        return TranslationResult(
            text: first.text,
            detectedSourceLanguage: first.detected_source_language?.lowercased()
        )
    }

    private func deepLSourceCode(_ code: String) -> String {
        code.uppercased()
    }

    private func deepLTargetCode(_ code: String) -> String {
        switch code.lowercased() {
        case "en":
            return "EN-US"
        case "pt":
            return "PT-PT"
        default:
            return code.uppercased()
        }
    }
}
