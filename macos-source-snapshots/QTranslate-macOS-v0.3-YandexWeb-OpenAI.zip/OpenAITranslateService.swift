import Foundation

final class OpenAITranslateService: TranslationService {

    enum OpenAIError: LocalizedError {
        case missingAPIKey
        case invalidResponse
        case apiError(String)
        case emptyOutput

        var errorDescription: String? {
            switch self {
            case .missingAPIKey:
                return "OpenAI API key is missing. Open Settings and add your key."
            case .invalidResponse:
                return "OpenAI returned an invalid response."
            case .apiError(let message):
                return message
            case .emptyOutput:
                return "OpenAI returned an empty translation."
            }
        }
    }

    func translate(
        _ request: TranslationRequest
    ) async throws -> TranslationResult {

        let apiKey = KeychainStore.read(
            account: "openai-api-key"
        )
        .trimmingCharacters(in: .whitespacesAndNewlines)

        guard !apiKey.isEmpty else {
            throw OpenAIError.missingAPIKey
        }

        let sourceDescription: String

        if let source = request.sourceLanguage {
            sourceDescription = LanguageOption.name(for: source)
        } else {
            sourceDescription = "auto-detected source language"
        }

        let targetDescription = LanguageOption.name(
            for: request.targetLanguage
        )

        let instructions = """
        You are a translation engine.
        Translate from \(sourceDescription) to \(targetDescription).
        Return only the translated text.
        Preserve paragraphs, line breaks, punctuation, URLs, names, numbers, and formatting where appropriate.
        Do not explain the translation and do not add quotation marks.
        """

        let payload: [String: Any] = [
            "model": AppSettings.openAIModel,
            "instructions": instructions,
            "input": request.text
        ]

        let body = try JSONSerialization.data(
            withJSONObject: payload
        )

        let url = URL(
            string: "https://api.openai.com/v1/responses"
        )!

        var urlRequest = URLRequest(url: url)
        urlRequest.httpMethod = "POST"
        urlRequest.setValue(
            "application/json",
            forHTTPHeaderField: "Content-Type"
        )
        urlRequest.setValue(
            "Bearer \(apiKey)",
            forHTTPHeaderField: "Authorization"
        )
        urlRequest.httpBody = body

        let session = NetworkSessionFactory.make(
            useSystemProxy: request.useSystemProxy
        )

        let (data, response) = try await session.data(
            for: urlRequest
        )

        guard let http = response as? HTTPURLResponse else {
            throw OpenAIError.invalidResponse
        }

        guard (200..<300).contains(http.statusCode) else {
            if let object = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
               let error = object["error"] as? [String: Any],
               let message = error["message"] as? String {
                throw OpenAIError.apiError(message)
            }

            throw OpenAIError.invalidResponse
        }

        guard let object = try JSONSerialization.jsonObject(with: data) as? [String: Any],
              let output = object["output"] as? [[String: Any]] else {
            throw OpenAIError.invalidResponse
        }

        var result = ""

        for item in output {
            guard let content = item["content"] as? [[String: Any]] else {
                continue
            }

            for part in content {
                guard let type = part["type"] as? String,
                      type == "output_text",
                      let text = part["text"] as? String else {
                    continue
                }

                result += text
            }
        }

        result = result.trimmingCharacters(
            in: .whitespacesAndNewlines
        )

        guard !result.isEmpty else {
            throw OpenAIError.emptyOutput
        }

        return TranslationResult(
            text: result,
            detectedSourceLanguage: request.sourceLanguage
        )
    }
}
