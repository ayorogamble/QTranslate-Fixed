import Foundation

enum TranslationProvider: String, CaseIterable, Identifiable {
    case google = "Google Translate"
    case deepl = "DeepL Web"
    case yandex = "Yandex Web"
    case openai = "OpenAI (ChatGPT)"

    var id: String { rawValue }
}
