import Foundation

enum AppSettings {
    static let settingsChanged = Notification.Name("QTranslateSettingsChanged")

    static var provider: TranslationProvider {
        get {
            let raw = UserDefaults.standard.string(forKey: "provider")
                ?? TranslationProvider.google.rawValue
            return TranslationProvider(rawValue: raw) ?? .google
        }
        set {
            UserDefaults.standard.set(newValue.rawValue, forKey: "provider")
        }
    }

    static var sourceLanguage: String {
        UserDefaults.standard.string(forKey: "sourceLanguage") ?? "auto"
    }

    static var targetLanguage: String {
        UserDefaults.standard.string(forKey: "targetLanguage") ?? "ru"
    }

    static var reverseLanguage: String {
        UserDefaults.standard.string(forKey: "reverseLanguage") ?? "en"
    }

    static var smartBidirectional: Bool {
        if UserDefaults.standard.object(forKey: "smartBidirectional") == nil {
            return true
        }
        return UserDefaults.standard.bool(forKey: "smartBidirectional")
    }

    static var useSystemProxy: Bool {
        if UserDefaults.standard.object(forKey: "useSystemProxy") == nil {
            return true
        }
        return UserDefaults.standard.bool(forKey: "useSystemProxy")
    }

    static var openAIModel: String {
        UserDefaults.standard.string(forKey: "openAIModel") ?? "gpt-5.6-luna"
    }

    static var translateModifier: String {
        UserDefaults.standard.string(forKey: "translateModifier") ?? "Control"
    }

    static var translateKey: String {
        UserDefaults.standard.string(forKey: "translateKey") ?? "q"
    }

    static var replaceModifier: String {
        UserDefaults.standard.string(forKey: "replaceModifier") ?? "Control"
    }

    static var replaceKey: String {
        UserDefaults.standard.string(forKey: "replaceKey") ?? "w"
    }

    static var layoutModifier: String {
        UserDefaults.standard.string(forKey: "layoutModifier") ?? "Control"
    }

    static var layoutKey: String {
        UserDefaults.standard.string(forKey: "layoutKey") ?? "d"
    }
}
