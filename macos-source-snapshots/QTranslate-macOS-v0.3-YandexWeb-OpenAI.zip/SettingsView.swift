import SwiftUI

struct SettingsView: View {
    @AppStorage("provider") private var provider =
        TranslationProvider.google.rawValue

    @AppStorage("sourceLanguage") private var sourceLanguage = "auto"
    @AppStorage("targetLanguage") private var targetLanguage = "ru"
    @AppStorage("reverseLanguage") private var reverseLanguage = "en"
    @AppStorage("smartBidirectional") private var smartBidirectional = true
    @AppStorage("useSystemProxy") private var useSystemProxy = true
    @AppStorage("openAIModel") private var openAIModel = "gpt-5.6-luna"

    @AppStorage("translateModifier") private var translateModifier = "Control"
    @AppStorage("translateKey") private var translateKey = "q"

    @AppStorage("replaceModifier") private var replaceModifier = "Control"
    @AppStorage("replaceKey") private var replaceKey = "w"

    @AppStorage("layoutModifier") private var layoutModifier = "Control"
    @AppStorage("layoutKey") private var layoutKey = "d"

    @State private var openAIAPIKey = ""

    var body: some View {
        Form {
            Section("Translator") {
                Picker("Engine", selection: $provider) {
                    ForEach(TranslationProvider.allCases) { provider in
                        Text(provider.rawValue)
                            .tag(provider.rawValue)
                    }
                }

                Picker("Source language", selection: $sourceLanguage) {
                    ForEach(LanguageOption.popular) { language in
                        Text(language.name)
                            .tag(language.code)
                    }
                }

                Picker("Target language", selection: $targetLanguage) {
                    ForEach(LanguageOption.targets) { language in
                        Text(language.name)
                            .tag(language.code)
                    }
                }

                Toggle(
                    "Smart bidirectional mode",
                    isOn: $smartBidirectional
                )

                if smartBidirectional {
                    Picker("Reverse target", selection: $reverseLanguage) {
                        ForEach(LanguageOption.targets) { language in
                            Text(language.name)
                                .tag(language.code)
                        }
                    }

                    Text(
                        "Example: target Russian + reverse English means English → Russian, but Russian → English."
                    )
                    .font(.caption)
                    .foregroundStyle(.secondary)
                }
            }

            Section("Network") {
                Toggle(
                    "Use macOS system proxy",
                    isOn: $useSystemProxy
                )

                Text(
                    "When enabled, translator requests follow macOS system proxy settings."
                )
                .font(.caption)
                .foregroundStyle(.secondary)
            }

            Section("DeepL Web") {
                Text(
                    "No API key required. Uses an unofficial DeepL web endpoint and may stop working if DeepL changes it."
                )
                .font(.caption)
                .foregroundStyle(.secondary)
            }

            Section("Yandex Web") {
                Text(
                    "No API key required. Uses a browser-style Yandex Translate session and may stop working if Yandex changes its web API."
                )
                .font(.caption)
                .foregroundStyle(.secondary)
            }

            Section("OpenAI (ChatGPT)") {
                SecureField(
                    "OpenAI API key",
                    text: $openAIAPIKey
                )

                Picker("Model", selection: $openAIModel) {
                    Text("GPT-5.6 Luna")
                        .tag("gpt-5.6-luna")
                    Text("GPT-5.6 Terra")
                        .tag("gpt-5.6-terra")
                    Text("GPT-5.6 Sol")
                        .tag("gpt-5.6-sol")
                }

                Link(
                    "Create / manage OpenAI API keys",
                    destination: URL(
                        string: "https://platform.openai.com/api-keys"
                    )!
                )

                Text(
                    "The API key is stored in macOS Keychain. OpenAI API billing is separate from a ChatGPT subscription."
                )
                .font(.caption)
                .foregroundStyle(.secondary)
            }

            Section("Hotkeys") {
                HotKeyRow(
                    title: "Show translation",
                    modifier: $translateModifier,
                    key: $translateKey
                )

                HotKeyRow(
                    title: "Translate and replace",
                    modifier: $replaceModifier,
                    key: $replaceKey
                )

                HotKeyRow(
                    title: "Fix keyboard layout",
                    modifier: $layoutModifier,
                    key: $layoutKey
                )
            }

            HStack {
                Spacer()

                Button("Apply") {
                    let trimmed = openAIAPIKey.trimmingCharacters(
                        in: .whitespacesAndNewlines
                    )

                    if trimmed.isEmpty {
                        KeychainStore.delete(
                            account: "openai-api-key"
                        )
                    } else {
                        KeychainStore.save(
                            trimmed,
                            account: "openai-api-key"
                        )
                    }

                    NotificationCenter.default.post(
                        name: AppSettings.settingsChanged,
                        object: nil
                    )
                }
                .keyboardShortcut(.defaultAction)
            }
        }
        .formStyle(.grouped)
        .frame(width: 580, height: 790)
        .padding()
        .onAppear {
            openAIAPIKey = KeychainStore.read(
                account: "openai-api-key"
            )
        }
    }
}

private struct HotKeyRow: View {
    let title: String
    @Binding var modifier: String
    @Binding var key: String

    var body: some View {
        HStack {
            Text(title)
                .frame(width: 170, alignment: .leading)

            Picker("", selection: $modifier) {
                ForEach(HotKeyModifier.allCases) { item in
                    Text(item.rawValue)
                        .tag(item.rawValue)
                }
            }
            .labelsHidden()
            .frame(width: 170)

            Picker("", selection: $key) {
                ForEach(HotKeyKey.available, id: \.self) { key in
                    Text(key.uppercased())
                        .tag(key)
                }
            }
            .labelsHidden()
            .frame(width: 80)
        }
    }
}
