QTranslate macOS v0.3 patch

Replace these files from v0.2:
- TranslationProvider.swift
- AppSettings.swift
- YandexTranslateService.swift
- TranslationManager.swift
- SettingsView.swift

Add:
- KeychainStore.swift
- OpenAITranslateService.swift

Yandex Web:
No API key. Browser-style Yandex Translate session.
This is unofficial and can break when Yandex changes the website API.

OpenAI:
The user enters their own OpenAI API key in Settings.
The key is stored in macOS Keychain.
Default model: gpt-5.6-luna

After copying:
1. Make sure every Swift file has Qtranslate Target Membership checked.
2. Shift + Command + K
3. Command + B
4. Command + R
