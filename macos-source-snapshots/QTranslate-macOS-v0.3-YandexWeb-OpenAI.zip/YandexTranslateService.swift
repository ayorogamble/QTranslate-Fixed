import Foundation

final class YandexTranslateService: TranslationService {

    enum YandexError: LocalizedError {
        case sessionFailed
        case invalidResponse
        case emptyTranslation

        var errorDescription: String? {
            switch self {
            case .sessionFailed:
                return "Yandex Web session could not be created."
            case .invalidResponse:
                return "Yandex Web returned an invalid response."
            case .emptyTranslation:
                return "Yandex Web returned an empty translation."
            }
        }
    }

    private struct BrowserSession {
        let id: String
        let expiresAt: Date
    }

    private var proxiedBrowserSession: BrowserSession?
    private var directBrowserSession: BrowserSession?

    private lazy var proxiedURLSession: URLSession = {
        let configuration = URLSessionConfiguration.default
        configuration.httpShouldSetCookies = true
        configuration.httpCookieAcceptPolicy = .always
        return URLSession(configuration: configuration)
    }()

    private lazy var directURLSession: URLSession = {
        let configuration = URLSessionConfiguration.ephemeral
        configuration.connectionProxyDictionary = [:]
        configuration.httpShouldSetCookies = true
        configuration.httpCookieAcceptPolicy = .always
        return URLSession(configuration: configuration)
    }()

    func translate(
        _ request: TranslationRequest
    ) async throws -> TranslationResult {

        let session = request.useSystemProxy
            ? proxiedURLSession
            : directURLSession

        let browserSession = try await browserSession(
            useSystemProxy: request.useSystemProxy,
            urlSession: session
        )

        let security = securityQuery()

        var components = URLComponents(
            string: "https://translate.yandex.net/api/v1/tr.json/translate"
        )!

        components.queryItems = [
            URLQueryItem(
                name: "sid",
                value: "\(browserSession.id)-5-0"
            ),
            URLQueryItem(
                name: "source_lang",
                value: request.sourceLanguage ?? ""
            ),
            URLQueryItem(
                name: "target_lang",
                value: request.targetLanguage
            ),
            URLQueryItem(name: "reason", value: "paste"),
            URLQueryItem(name: "format", value: "text"),
            URLQueryItem(name: "strategy", value: "0"),
            URLQueryItem(name: "disable_cache", value: "false"),
            URLQueryItem(name: "ajax", value: "1"),
            URLQueryItem(name: "srv", value: "tr-text"),
            URLQueryItem(name: "yu", value: security.yu),
            URLQueryItem(name: "yum", value: security.yum)
        ]

        guard let url = components.url else {
            throw YandexError.invalidResponse
        }

        var urlRequest = URLRequest(url: url)
        urlRequest.httpMethod = "POST"
        addBrowserHeaders(to: &urlRequest)

        urlRequest.setValue(
            "application/x-www-form-urlencoded; charset=UTF-8",
            forHTTPHeaderField: "Content-Type"
        )

        var body = URLComponents()
        body.queryItems = [
            URLQueryItem(name: "options", value: "1"),
            URLQueryItem(name: "text", value: request.text)
        ]

        urlRequest.httpBody = body.percentEncodedQuery?.data(using: .utf8)

        let (data, response) = try await session.data(for: urlRequest)

        guard let http = response as? HTTPURLResponse,
              (200..<300).contains(http.statusCode) else {
            throw YandexError.invalidResponse
        }

        guard let object = try JSONSerialization.jsonObject(with: data) as? [String: Any],
              let textArray = object["text"] as? [String],
              !textArray.isEmpty else {
            throw YandexError.invalidResponse
        }

        let translated = textArray.joined(separator: "\n")

        guard !translated.isEmpty else {
            throw YandexError.emptyTranslation
        }

        let detected: String?

        if let source = object["lang"] as? String,
           source.contains("-") {
            detected = source.split(separator: "-").first.map(String.init)
        } else {
            detected = request.sourceLanguage
        }

        return TranslationResult(
            text: translated,
            detectedSourceLanguage: detected
        )
    }

    private func browserSession(
        useSystemProxy: Bool,
        urlSession: URLSession
    ) async throws -> BrowserSession {

        if useSystemProxy,
           let existing = proxiedBrowserSession,
           existing.expiresAt > Date().addingTimeInterval(60) {
            return existing
        }

        if !useSystemProxy,
           let existing = directBrowserSession,
           existing.expiresAt > Date().addingTimeInterval(60) {
            return existing
        }

        let security = securityQuery()

        var components = URLComponents(
            string: "https://translate.yandex.ru/props/api/v1.0/sessions"
        )!

        components.queryItems = [
            URLQueryItem(name: "srv", value: "tr-text"),
            URLQueryItem(name: "yu", value: security.yu),
            URLQueryItem(name: "yum", value: security.yum)
        ]

        guard let url = components.url else {
            throw YandexError.sessionFailed
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        addBrowserHeaders(to: &request)

        let (data, response) = try await urlSession.data(for: request)

        guard let http = response as? HTTPURLResponse,
              (200..<300).contains(http.statusCode),
              let object = try JSONSerialization.jsonObject(with: data) as? [String: Any],
              let sessionObject = object["session"] as? [String: Any],
              let id = sessionObject["id"] as? String else {
            throw YandexError.sessionFailed
        }

        let maxAge: TimeInterval

        if let number = sessionObject["maxAge"] as? NSNumber {
            maxAge = number.doubleValue
        } else if let intValue = sessionObject["maxAge"] as? Int {
            maxAge = TimeInterval(intValue)
        } else {
            maxAge = 1800
        }

        let result = BrowserSession(
            id: id,
            expiresAt: Date().addingTimeInterval(maxAge)
        )

        if useSystemProxy {
            proxiedBrowserSession = result
        } else {
            directBrowserSession = result
        }

        return result
    }

    private func addBrowserHeaders(to request: inout URLRequest) {
        request.setValue(
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 Chrome/152 Safari/537.36",
            forHTTPHeaderField: "User-Agent"
        )

        request.setValue(
            "https://translate.yandex.ru",
            forHTTPHeaderField: "Referer"
        )

        request.setValue(
            "https://translate.yandex.ru",
            forHTTPHeaderField: "Origin"
        )

        request.setValue(
            "application/json, text/plain, */*",
            forHTTPHeaderField: "Accept"
        )
    }

    private func securityQuery() -> (
        yu: String,
        yum: String
    ) {
        let yu = String(
            UInt64.random(
                in: 1_000_000_000_000_000_000...
                9_000_000_000_000_000_000
            )
        )

        let milliseconds = UInt64(
            Date().timeIntervalSince1970 * 1000
        )

        let yum = String(milliseconds * 1_000_000)

        return (yu, yum)
    }
}
