import Foundation

struct ManagedTranslationResult {
    let text: String
    let sourceLanguage: String?
    let targetLanguage: String
    let provider: TranslationProvider
}

final class TranslationManager {
    private let google = GoogleTranslateService()
    private let deepl = DeepLTranslateService()
    private let yandex = YandexTranslateService()
    private let openai = OpenAITranslateService()

    func translate(text: String) async throws -> ManagedTranslationResult {
        let requestedSource = AppSettings.sourceLanguage

        let detected = requestedSource == "auto"
            ? LanguageDetector.detect(text)
            : requestedSource

        var effectiveTarget = AppSettings.targetLanguage

        if AppSettings.smartBidirectional,
           let detected,
           detected.lowercased() == AppSettings.targetLanguage.lowercased() {
            effectiveTarget = AppSettings.reverseLanguage
        }

        let request = TranslationRequest(
            text: text,
            sourceLanguage: requestedSource == "auto" ? nil : requestedSource,
            targetLanguage: effectiveTarget,
            useSystemProxy: AppSettings.useSystemProxy
        )

        let provider = AppSettings.provider
        let result: TranslationResult

        switch provider {
        case .google:
            result = try await google.translate(request)

        case .deepl:
            result = try await deepl.translate(request)

        case .yandex:
            result = try await yandex.translate(request)

        case .openai:
            result = try await openai.translate(request)
        }

        return ManagedTranslationResult(
            text: result.text,
            sourceLanguage: result.detectedSourceLanguage ?? detected,
            targetLanguage: effectiveTarget,
            provider: provider
        )
    }
}
